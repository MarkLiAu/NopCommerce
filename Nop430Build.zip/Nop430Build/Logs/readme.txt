﻿This folder is used only for system logging by ASP.NET (could be enabled in web.config file)

nopCommerce uses its own logging implementation (available in admin area)